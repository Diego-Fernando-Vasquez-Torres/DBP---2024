const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const { GraphQLSchema, GraphQLObjectType, GraphQLString, GraphQLList } = require('graphql');

//nuestros datos de 10 libros
const booksData = [
  { id: 1, titulo: 'El Señor de los Anillos', autor: 'J.R.R. Tolkien' },
  { id: 2, titulo: 'Harry Potter y la piedra filosofal', autor: 'J.K. Rowling' },
  { id: 3, titulo: 'Cien años de soledad', autor: 'Gabriel García Márquez' },
  { id: 4, titulo: '1984', autor: 'George Orwell' },
  { id: 5, titulo: 'Orgullo y prejuicio', autor: 'Jane Austen' },
  { id: 6, titulo: 'Don Quijote de la Mancha', autor: 'Miguel de Cervantes' },
  { id: 7, titulo: 'Matar un ruiseñor', autor: 'Harper Lee' },
  { id: 8, titulo: 'El Hobbit', autor: 'J.R.R. Tolkien' },
  { id: 9, titulo: 'Crimen y castigo', autor: 'Fyodor Dostoevsky' },
  { id: 10, titulo: 'Las aventuras de Tom Sawyer', autor: 'Mark Twain' }
];

const BookType = new GraphQLObjectType({
  name: 'Book',
  fields: () => ({
    id: { type: GraphQLString },
    titulo: { type: GraphQLString },
    autor: { type: GraphQLString }
  })
});


//resolver book que te muestra los libros
//resolver hello que devuelve el saludo en funcion de la hora
const RootQueryType = new GraphQLObjectType({
  name: 'Query',
  fields: {
    hello: {
        type: GraphQLString,
        resolve: () => {
          const hour = new Date().getHours();
          let saludo = "";
          if (hour >= 6 && hour < 12) {
            saludo = "Buenos días";
          } else if (hour >= 12 && hour < 18) {
            saludo = "Buenas tardes";
          } else {
            saludo = "Buenas noches";
          }
          return `¡Hola!, ${saludo}`;
        }
      },
    books: {
      type: new GraphQLList(BookType),
      resolve: () => booksData
    }
  }
});

const schema = new GraphQLSchema({
  query: RootQueryType
});

const app = express();

app.use('/graphql', graphqlHTTP({
  schema: schema,
  graphiql: true 
}));

//aqui iniciamos el servidor
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Servidor GraphQL corriendo en http://localhost:${PORT}/graphql`));
